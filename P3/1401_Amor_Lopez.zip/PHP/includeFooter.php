<!--<script src="../JS/register.js"></script>-->

<footer>
    <p class="authors">Antonio Amor, Esther López, Sistemas Informáticos</p>
    <p id="concurrent"><?php include("concurrent-users.php");?></p>
</footer>

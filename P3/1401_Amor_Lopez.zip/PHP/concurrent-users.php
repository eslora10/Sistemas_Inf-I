<?php
    echo "Usuarios concurrentes: ".rand(0, 1000);
?>

